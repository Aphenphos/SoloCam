import ezdxf
import sys
import math

from Coordinate import *

def getCoords(dxfFile):
    try:
        source = ezdxf.readfile(dxfFile)
    except IOError:
        print("Not a DXF file or generic IO Err")
    except ezdxf.DXFStructureError:
        print("Invalid or corrupt DXF File")
        sys.exit(2)
        
    coords = []
    msp = source.modelspace()
##  Step defines accuracy of an arc or circle (Lower is more accurate)
    step = 10000
    for e in msp:
        match e.dxftype():
            case 'POINT':
                coords.append(Coordinate(
                    EType.POINT,
                    e.dxf.x,
                    e.dxf.y ))
            case 'LINE':
##              Append start and end of line back to back
                coords.append(Coordinate(
                    EType.LINE,
                    e.dxf.start.x,
                    e.dxf.start.y, 
                    start=True
                ))
                coords.append(Coordinate(
                    EType.LINE,
                    e.dxf.end.x,
                    e.dxf.end.y,
                    end=True
                ))
            case 'LWPOLYLINE':
                length = len(e.get_points('xy')) -1
                for ind, v in enumerate(e.get_points('xy')):
                    if (ind == 0):
                        coords.append(Coordinate(
                            EType.LWPOLYLINE,
                            v[0],
                            v[1],
                            start = True
                        )) 
                    if (ind == length):
                        coords.append(Coordinate(
                            EType.LWPOLYLINE,
                            v[0],
                            v[1],
                            end = True
                        ))
                        break
                    coords.append(Coordinate(
                        EType.LWPOLYLINE,
                        v[0],
                        v[1]
                    ))
            case 'ARC':
                center = (e.dxf.center.x, e.dxf.center.y)
                radius = e.dxf.radius
                start = math.degrees(e.dxf.start_angle)
                end = math.degrees(e.dxf.end_angle)
                x = 0
                y = 0
                length = len(range(int(start), int(end), step)) - 1
                for ind, a in enumerate(range(int(start), int(end), step)):
                    if (ind == 0):
                        x = center[0] + radius * math.cos(math.radians(a))
                        y = center[1] + radius * math.sin(math.radians(a))
                        coords.append(Coordinate(
                            EType.ARC,
                            x,
                            y,
                            radius,
                            center = center,
                            start = True
                        ))
                    if (ind == length):
                        x = center[0] + radius * math.cos(math.radians(a))
                        y = center[1] + radius * math.sin(math.radians(a))
                        coords.append(Coordinate(
                            EType.ARC,
                            x,
                            y,
                            radius,
                            center = center,
                            end = True
                        ))
                        break

            case 'CIRCLE':
                center = (e.dxf.center.x, e.dxf.center.y)
                radius = e.dxf.radius
                length = len(range(0, 360, step)) - 1
                for ind, a in enumerate(range(0, 360, step)):
                    if (ind == 0):
                        x = center[0] + radius * math.cos(math.radians(a))
                        y = center[1] + radius * math.sin(math.radians(a))
                        coords.append(Coordinate(
                            EType.CIRCLE,
                            x,
                            y,
                            radius,
                            center = center,
                            start = True
                        ))
                    if (ind == length):
                        x = center[0] + radius * math.cos(math.radians(a))
                        y = center[1] + radius * math.sin(math.radians(a))
                        coords.append(Coordinate(
                            EType.CIRCLE,
                            x,
                            y,
                            radius,
                            center = center,
                            end = True
                        ))            
                        break            
    out = open(f"{dxfFile}Out.txt", "w")
    for c in coords:
        out.write(c.toFile())
    out.close()

    return coords


  
getCoords(sys.argv[1])