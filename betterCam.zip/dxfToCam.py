from Coordinate import *
from Code import *


#I and J are determined by subtracting the center of the arc from start xy
def generateArc(arcCoords):


